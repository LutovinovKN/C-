﻿// Задача №6

Console.Write("Введите число: ");
int number1 = Convert.ToInt32(Console.ReadLine());
if (number1 % 2 == 0)
{
    Console.WriteLine($"Да");
}
else
{
    Console.WriteLine($"Нет");
}